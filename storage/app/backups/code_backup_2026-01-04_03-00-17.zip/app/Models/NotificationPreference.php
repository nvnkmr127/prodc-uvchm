<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Traits\WebhookEnabled;

class NotificationPreference extends Model
{
    use WebhookEnabled;

    protected $fillable = [
        'user_id', 'notification_type', 'category', 'enabled', 'settings'
    ];

    protected $casts = [
        'enabled' => 'boolean',
        'settings' => 'array',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    // Get preference for a user
    public static function getPreference($userId, $type, $category): bool
    {
        return static::where([
            'user_id' => $userId,
            'notification_type' => $type,
            'category' => $category
        ])->value('enabled') ?? true; // Default to enabled
    }

    // Set preference for a user
    public static function setPreference($userId, $type, $category, $enabled, $settings = [])
    {
        return static::updateOrCreate([
            'user_id' => $userId,
            'notification_type' => $type,
            'category' => $category
        ], [
            'enabled' => $enabled,
            'settings' => $settings
        ]);
    }
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StudentPortalActivityLog extends Model
{
    public $timestamps = false; // We only use created_at

    protected $fillable = [
        'student_id',
        'action',
        'ip_address',
        'user_agent',
        'mobile_number',
        'location_data',
        'metadata'
    ];

    protected $casts = [
        'location_data' => 'array',
        'metadata' => 'array',
        'created_at' => 'datetime'
    ];

    /**
     * Relationship to Student
     */
    public function student()
    {
        return $this->belongsTo(\App\Models\Student::class);
    }

    /**
     * Log an activity
     */
    public static function logActivity($studentId, $action, $metadata = [])
    {
        $request = request();

        return self::create([
            'student_id' => $studentId,
            'action' => $action,
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'mobile_number' => session('student_portal_mobile'),
            'location_data' => self::getLocationFromIp($request->ip()),
            'metadata' => $metadata
        ]);
    }

    /**
     * Get location data from IP address using free API
     */
    private static function getLocationFromIp($ip)
    {
        // Skip for local IPs
        if ($ip === '127.0.0.1' || $ip === '::1' || str_starts_with($ip, '192.168.')) {
            return ['city' => 'Local', 'country' => 'Local'];
        }

        try {
            $response = file_get_contents("http://ip-api.com/json/{$ip}?fields=status,country,city,lat,lon");
            $data = json_decode($response, true);

            if ($data && $data['status'] === 'success') {
                return [
                    'country' => $data['country'] ?? null,
                    'city' => $data['city'] ?? null,
                    'lat' => $data['lat'] ?? null,
                    'lon' => $data['lon'] ?? null
                ];
            }
        } catch (\Exception $e) {
            // Silently fail and return null
        }

        return null;
    }
}
